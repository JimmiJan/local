const Pass = (f) => {

    if (f.className == "fas fa-eye eye") {
        password.type = "text"
        f.className = "fas fa-eye-slash pass"

    } else {
        password.type = "password"
        f.className = "fas fa-eye pass"
    }

    // console.log(f);

}





const names= document.getElementById("name")
const lName = document.getElementById("lName")
const email = document.getElementById("email")
const pass = document.getElementById("password")


const para = (e) => {
    if (names.value < 3) {
        alert("please enter name")
    } else {
        // localStorage.setItem(key , value)
        localStorage.setItem("myName", names.value)
        localStorage.setItem("lName", lName.value)
        localStorage.setItem("email", email.value)
        localStorage.setItem("pass", password.value)
         
        // window.location.assign("")

    }

}

let kuchBhi = document.getElementById("kuchBhi")
    console.log(kuchBhi);
kuchBhi.innerHTML= names.value

